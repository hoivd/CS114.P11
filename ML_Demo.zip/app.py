from flask import Flask, request, jsonify, render_template
from tensorflow.keras.preprocessing.image import img_to_array, load_img
from tensorflow.keras.applications import MobileNetV3Large
from tensorflow.keras.applications.mobilenet_v3 import preprocess_input
from joblib import load
import numpy as np
import os
from threading import Timer
import webbrowser

# Tập nhãn các thương hiệu xe
cars_brand_set = {
    0: 'Others', 1: 'Honda', 2: 'Hyundai', 3: 'KIA',
    4: 'Mazda', 5: 'Mitsubishi', 6: 'Suzuki',
    7: 'Toyota', 8: 'VinFast'
}

# Khởi tạo Flask app
app = Flask(__name__)

# Load mô hình Logistic Regression đã lưu
model = load("logistic_regression_model.joblib")

# Load mô hình trích xuất đặc trưng
model_extract_feature = MobileNetV3Large(weights='imagenet', include_top=False, input_shape=(224, 224, 3))

# Đường dẫn lưu trữ ảnh tải lên
UPLOAD_FOLDER = "uploads"
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Hàm tiền xử lý ảnh
def preprocess_image(image_path):
    try:
        img = load_img(image_path, target_size=(224, 224))  # Thay đổi kích thước ảnh
    except Exception as e:
        raise ValueError(f"Error loading image {image_path}: {e}")

    x = img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)

    # Trích xuất đặc trưng
    feature = model_extract_feature.predict(x)
    feature = feature.flatten().reshape(1, -1)  # Chuyển về định dạng phù hợp cho Logistic Regression
    return feature

# Route để hiển thị trang HTML
@app.route('/')
def index():
    return render_template('index.html')

# Route để xử lý ảnh tải lên
@app.route('/predict', methods=['POST'])
def predict():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    file_path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
    file.save(file_path)

    try:
        # Tiền xử lý ảnh
        image = preprocess_image(file_path)

        # Dự đoán với Logistic Regression
        predicted_class = model.predict(image)[0]  # Trả về nhãn lớp

        # Xóa file ảnh đã tải lên để tiết kiệm bộ nhớ
        os.remove(file_path)

        # Trả kết quả
        return jsonify({
            "predicted_class": cars_brand_set[predicted_class]  # Ánh xạ nhãn lớp thành tên thương hiệu
        })
    except Exception as e:
        os.remove(file_path)
        return jsonify({"error": str(e)}), 500

# Chạy Flask server
if __name__ == "__main__":
    # Định nghĩa URL mà Flask chạy
    url = "http://127.0.0.1:5000"

    # Sử dụng Timer để mở trình duyệt sau khi server khởi chạy
    Timer(1, lambda: webbrowser.open(url)).start()

    # Chạy Flask server
    app.run(debug=True)
